<h1>Atividade: <?php echo e($atividade->id); ?></h1>
<hr>
	<h3>Título: <?php echo e($atividade->title); ?></h3>
	<p>Descrição: <?php echo e($atividade->description); ?></p>
	<p>Data de entrega: <?php echo e($atividade->scheduledto); ?></p>
	<p>Criado em: <?php echo e($atividade->created_at); ?></p>
	<p>Atualizado em: <?php echo e($atividade->updated_at); ?></p>
	<br>
	