<h1>Lista de mensagens</h1>
<hr>
<br>
<br>
@foreach($lmsg as $umaMsg)
    <p><b>{{$umaMsg->titulo}}</b></p>
    <p>{{$umaMsg->texto}}</p>
    <p>{{$umaMsg->autor}}</p>
    <p>{{$umaMsg->created_at}}</p>
    <br>
    <br>
@endforeach




