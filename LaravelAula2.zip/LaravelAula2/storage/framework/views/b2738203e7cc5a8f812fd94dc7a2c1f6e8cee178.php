<h3><b>ID:</b> <?php echo e($atividade->id); ?></h3>
<h3><b>Título:</b> <?php echo e($atividade->title); ?></h3>