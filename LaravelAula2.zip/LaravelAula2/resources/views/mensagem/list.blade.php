<h1>Lista de mensagens</h1>
<hr>
@foreach($lmsg as $umaMsg)
    <p><a href="/mensagens/{{$umaMsg->id}}">{{$umaMsg->titulo}}</a></p>
@endforeach




