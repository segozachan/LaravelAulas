<h1>Lista de mensagens</h1>
<hr>
<?php $__currentLoopData = $lmsg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umaMsg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><a href="/mensagens/<?php echo e($umaMsg->id); ?>"><?php echo e($umaMsg->titulo); ?></a></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




