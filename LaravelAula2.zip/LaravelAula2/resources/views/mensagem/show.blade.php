<h1>Mensagem: {{$mensagem->id}}</h1>
<hr>
    <h3>Título: {{$mensagem->titulo}}</h3>
    <p>Texto: {{$mensagem->texto}}</p>
    <p>Autor: {{$mensagem->autor}}</p>
    <p>Criado em: {{$mensagem->created_at}}</p>
    <p>Atualizado em: {{$mensagem->updated_at}}</p>
    <br>


