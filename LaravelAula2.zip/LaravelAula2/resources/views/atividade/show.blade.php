<h1>Atividade: {{$atividade->id}}</h1>
<hr>
	<h3>Título: {{$atividade->title}}</h3>
	<p>Descrição: {{$atividade->description}}</p>
	<p>Data de entrega: {{$atividade->scheduledto}}</p>
	<p>Criado em: {{$atividade->created_at}}</p>
	<p>Atualizado em: {{$atividade->updated_at}}</p>
	<br>
	