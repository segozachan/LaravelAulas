<h1>Mensagem: <?php echo e($mensagem->id); ?></h1>
<hr>
    <h3>Título: <?php echo e($mensagem->titulo); ?></h3>
    <p>Texto: <?php echo e($mensagem->texto); ?></p>
    <p>Autor: <?php echo e($mensagem->autor); ?></p>
    <p>Criado em: <?php echo e($mensagem->created_at); ?></p>
    <p>Atualizado em: <?php echo e($mensagem->updated_at); ?></p>
    <br>


