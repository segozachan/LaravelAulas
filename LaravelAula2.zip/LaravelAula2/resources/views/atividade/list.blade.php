<h1>Lista de Atividades</h1>
<hr>
@foreach($atividades as $atividade)
	<p><a href="/atividades/{{$atividade->id}}">{{$atividade->title}}</a></p>
@endforeach



<!-- \Carbon\Carbon::parse($atividade->scheduledto)->format('d/m/Y h:m')  -->